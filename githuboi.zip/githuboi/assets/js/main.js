fetch('data/game.json')
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById('produk-container')
    container.innerHTML = ''
    data.forEach(p => {
      const item = document.createElement('div')
      item.className = 'produk'
      item.innerHTML = `<h2>${p.nama}</h2><p>Rp${p.harga.toLocaleString()}</p>`
      container.appendChild(item)
    })
  })