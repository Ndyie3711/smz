fetch('transaksi.json')
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById('transaksi-container')
    data.forEach(trx => {
      const div = document.createElement('div')
      div.className = 'transaksi'
      div.innerHTML = `
        <strong>ID:</strong> ${trx.id}<br>
        <strong>Pengguna:</strong> ${trx.user}<br>
        <strong>Produk:</strong> ${trx.produk.nama}<br>
        <strong>Status:</strong> ${trx.status}
      `
      container.appendChild(div)
    })
  })
  .catch(err => console.error('Gagal ambil data transaksi:', err))